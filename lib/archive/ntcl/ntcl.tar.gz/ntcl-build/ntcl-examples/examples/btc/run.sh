#!/bin/sh

configfile=configfile.small
../../bin/btc.x configfile=${configfile}
