#!/bin/sh

configfile=mm.ini
../../bin/timed_mm.x configfile=${configfile}
