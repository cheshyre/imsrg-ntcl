#!/bin/sh

configfile=permute.ini
../../bin/timed_permute.x configfile=${configfile}
