#!/bin/sh

configfile=configfile.small
../../bin/timed_btc.x configfile=${configfile}
