#!/bin/sh

configfile=configfile.small
../../bin/timed_tc.x configfile=${configfile}
