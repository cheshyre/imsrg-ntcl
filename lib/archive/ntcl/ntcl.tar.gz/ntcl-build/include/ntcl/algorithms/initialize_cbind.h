// Copyright 2022 Matthias Heinz
#ifndef NTCL_ALGORITHMS_INITIALIZE_CBIND_H_
#define NTCL_ALGORITHMS_INITIALIZE_CBIND_H_

extern "C" {
void algorithms_initialize_c_compat();
void algorithms_finalize_c_compat();
}

#endif  // NTCL_ALGORITHMS_INITIALIZE_CBIND_H_
