// Copyright 2022 Matthias Heinz
#ifndef NTCL_DATA_CFI_UTIL_H_
#define NTCL_DATA_CFI_UTIL_H_

#include <ISO_Fortran_binding.h>

#include <array>
#include <cstdlib>
#include <iostream>
#include <utility>

#include "ntcl/data/cfi_types.h"

namespace ntcl {
namespace internal {

template <typename T, std::size_t R>
struct CFI_tpl_cdesc_t {
  // void* base_addr;
  T* base_addr;  // Assume T* is same size as void* (might not be safe, but we
                 // can write a test for this)
  size_t elem_len;
  int version;
  CFI_rank_t rank;
  CFI_attribute_t attribute;
  CFI_type_t type;
  CFI_dim_t dim[R];
};

template <typename T, std::size_t R>
CFI_cdesc_t* GetBasicPointer(CFI_tpl_cdesc_t<T, R>* array_desc_ptr) {
  return reinterpret_cast<CFI_cdesc_t*>(array_desc_ptr);
}

template <typename T, std::size_t R>
CFI_tpl_cdesc_t<T, R> AllocateArray(const std::array<std::size_t, R>& dims) {
  CFI_tpl_cdesc_t<T, R> array_desc;
  {
    int ind = CFI_establish(
        GetBasicPointer(&array_desc), NULL, CFI_attribute_allocatable,
        ntcl::internal::CFI_Type_v<T>, ntcl::internal::CFI_Size_v<T>, R, NULL);
    if (ind != CFI_SUCCESS) {
      std::cout << "ERROR in CFI_establish\n";
      exit(EXIT_FAILURE);
    }
  }

  {
    CFI_index_t lower_bounds[R] = {};
    CFI_index_t upper_bounds[R] = {};
    for (std::size_t r = 0; r < R; r++) {
      lower_bounds[r] = 0;
      upper_bounds[r] = static_cast<CFI_index_t>(dims[r] - 1);
    }
    int ind = CFI_allocate(GetBasicPointer(&array_desc), lower_bounds,
                           upper_bounds, 0);
    if (ind != CFI_SUCCESS) {
      std::cout << "ERROR in CFI_allocate\n";
      exit(EXIT_FAILURE);
    }
  }
  return array_desc;
}

// Array descriptor is copied and then deallocated
// Leaves copied input descriptor in invalid state
// This is okay because this will only be called on destruction or reallocation
template <typename T, std::size_t R>
void DeallocateArray(CFI_tpl_cdesc_t<T, R> array_desc) {
  int ind = CFI_deallocate(GetBasicPointer(&array_desc));
  if (ind != CFI_SUCCESS) {
    std::cout << "ERROR in CFI_deallocate\n";
    exit(EXIT_FAILURE);
  }
}

// Swap for CFI_dim_t
inline void swap(CFI_dim_t& a, CFI_dim_t& b) {
  using std::swap;

  swap(a.lower_bound, b.lower_bound);
  swap(a.extent, b.extent);
  swap(a.sm, b.sm);
}

// Swap for templated CFI_cdesc_t
template <typename T, std::size_t R>
void swap(CFI_tpl_cdesc_t<T, R>& a, CFI_tpl_cdesc_t<T, R>& b) {
  using std::swap;

  swap(a.base_addr, b.base_addr);
  swap(a.elem_len, b.elem_len);
  swap(a.version, b.version);
  swap(a.rank, b.rank);
  swap(a.attribute, b.attribute);
  swap(a.type, b.type);

  for (std::size_t r = 0; r < R; r++) {
    swap(a.dim[r], b.dim[r]);
  }
}

}  // namespace internal
}  // namespace ntcl

#endif  //  NTCL_DATA_CFI_UTIL_H_
