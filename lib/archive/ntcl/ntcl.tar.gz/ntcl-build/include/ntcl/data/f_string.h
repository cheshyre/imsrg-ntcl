// Copyright 2022 Matthias Heinz
// Module for string objects that can be passed to Fortran.
// FString is a class to manage the resources held by the string
// and to package everything into a CFI descriptor.
// It is not meant for string manipulation
// and FString objects should be created as late before Fortran subroutine call
// as possible.
#ifndef NTCL_DATA_F_STRING_H_
#define NTCL_DATA_F_STRING_H_

#include <ISO_Fortran_binding.h>

#include <iostream>
#include <string>
#include <string_view>

#include "ntcl/data/cfi_util.h"

namespace ntcl {

class FString {
 private:
  ntcl::internal::CFI_tpl_cdesc_t<char, 1> string_desc_;

  static ntcl::internal::CFI_tpl_cdesc_t<char, 1> CreateDescriptor(
      std::string_view str) {
    auto string_desc = ntcl::internal::AllocateArray<char, 1>({str.size()});

    // Copy string into descriptor memory
    for (std::size_t i = 0; i < str.size(); i++) {
      string_desc.base_addr[i] = str[i];
    }

    return string_desc;
  }

 public:
  // Allow implicit conversions between string and FString
  FString(std::string_view str)  // NOLINT(runtime/explicit)
      : string_desc_(FString::CreateDescriptor(str)) {
    // Elem_len should not matter, but for some reason it does
    // (this seems to be a GCC bug that will be fixed in GCC 12)
    string_desc_.elem_len = sizeof(char);
    // Stride in memory is not actually set to the right size
    string_desc_.dim[0].sm = sizeof(char);
  }
  FString(const std::string& str)  // NOLINT(runtime/explicit)
      : FString(std::string_view(str)) {}
  FString(const char* str)  // NOLINT(runtime/explicit)
      : FString(std::string_view(str)) {}
  ~FString() { ntcl::internal::DeallocateArray(string_desc_); }

  // Not copyable or movable
  FString(const FString& other) = delete;
  FString(FString&& other) = delete;
  FString& operator=(const FString& other) = delete;
  FString& operator=(FString&& other) = delete;

  void Debug() const {
    std::cout << "elem_len = " << string_desc_.elem_len << "\n";
    std::cout << "version = " << string_desc_.version << "\n";
    std::cout << "attribute = " << static_cast<int>(string_desc_.attribute)
              << "\n";
    std::cout << "type = " << string_desc_.type << "\n";
    std::cout << "rank = " << static_cast<int>(string_desc_.rank) << "\n";
    std::cout << "dim = " << string_desc_.dim[0].lower_bound << ","
              << string_desc_.dim[0].extent << "," << string_desc_.dim[0].sm
              << "\n";
  }

  CFI_cdesc_t* CFIDescriptorPointer() {
    return ntcl::internal::GetBasicPointer(&string_desc_);
  }

  CFI_cdesc_t* CFIDescriptorPointer() const {
    return ntcl::internal::GetBasicPointer(
        const_cast<ntcl::internal::CFI_tpl_cdesc_t<char, 1>*>(&string_desc_));
  }
};
}  // namespace ntcl

#endif  //  NTCL_DATA_F_STRING_H_
