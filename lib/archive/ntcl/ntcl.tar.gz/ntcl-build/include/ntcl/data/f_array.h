// Copyright 2022 Matthias Heinz
#ifndef NTCL_DATA_F_ARRAY_H_
#define NTCL_DATA_F_ARRAY_H_

#include <ISO_Fortran_binding.h>

#include <array>
#include <complex>
#include <cstdlib>
#include <utility>

#include "ntcl/data/cfi_util.h"

namespace ntcl {

namespace internal {

// Helper method to convert parameter packs to std::array<std::size_t, ...>
template <typename... Args>
std::array<std::size_t, sizeof...(Args)> ParameterPackToSizeTArray(
    Args&&... args) {
  return {{static_cast<std::size_t>(args)...}};
}

// Helper method to generate T* strides from memory strides
template <typename T, std::size_t R>
std::array<std::size_t, R> ComputeStrides(
    const ntcl::internal::CFI_tpl_cdesc_t<T, R>& desc) {
  std::array<std::size_t, R> strides = {};
  for (std::size_t r = 0; r < R; r++) {
    if (r == 0) {
      strides[r] = 1;
    } else {
      strides[r] =
          static_cast<std::size_t>(strides[r - 1] * desc.dim[r - 1].extent);
    }
  }
  return strides;
}

// Helper method to compute total size of array
template <std::size_t R>
std::size_t ComputeSize(const std::array<std::size_t, R>& dims) {
  std::size_t total_size = 1;
  for (std::size_t r = 0; r < R; r++) {
    total_size *= dims[r];
  }
  return total_size;
}

// Helper method to compute total flat index from array of indices and
// associated strides
template <std::size_t R>
std::size_t ComputeIndex(const std::array<std::size_t, R>& indices,
                         const std::array<std::size_t, R>& strides) {
  std::size_t index = 0;
  for (std::size_t r = 0; r < R; r++) {
    index += indices[r] * strides[r];
  }
  return index;
}

// Helper method to determine if 2 std::size_t arrays are equal
template <std::size_t R>
bool CompareArrays(const std::array<std::size_t, R>& a,
                   const std::array<std::size_t, R>& b) {
  for (std::size_t r = 0; r < R; r++) {
    if (a[r] != b[r]) {
      return false;
    }
  }

  return true;
}

template <typename T, std::size_t R>
class FArrayData {
 protected:
  ntcl::internal::CFI_tpl_cdesc_t<T, R> array_desc_;
  std::array<std::size_t, R> dims_;
  std::array<std::size_t, R> strides_;
  std::size_t size_;
  bool null_state_;

 public:
  explicit FArrayData(std::array<std::size_t, R> dims)
      : array_desc_(ntcl::internal::AllocateArray<T>(dims)),
        dims_(dims),
        strides_(ntcl::internal::ComputeStrides(array_desc_)),
        size_(ntcl::internal::ComputeSize(dims_)),
        null_state_(false) {}

  FArrayData(const FArrayData<T, R>& other)
      : array_desc_(ntcl::internal::AllocateArray<T, R>(other.dims_)),
        dims_(other.dims_),
        strides_(ntcl::internal::ComputeStrides(array_desc_)),
        size_(ntcl::internal::ComputeSize(dims_)),
        null_state_(false) {
    for (std::size_t index = 0; index < size_; index++) {
      array_desc_.base_addr[index] = other.array_desc_.base_addr[index];
    }
  }

  FArrayData(FArrayData<T, R>&& other) noexcept : FArrayData() { swap(other); }

  FArrayData<T, R>& operator=(FArrayData<T, R>&& other) noexcept {
    swap(other);
    return *this;
  }

  ~FArrayData() {
    if (!null_state_) {
      ntcl::internal::DeallocateArray(array_desc_);
    }
  }

  FArrayData& operator=(const FArrayData<T, R>& other) {
    // Can safely assume that this and other are not in null_state
    if (!ntcl::internal::CompareArrays(dims_, other.dims_)) {
      ntcl::internal::DeallocateArray(array_desc_);
      array_desc_ = ntcl::internal::AllocateArray(other.dims_);
      dims_ = other.dims_;
      strides_ = other.strides_;
      size_ = other.size_;
      // Trivial because both are not null
      null_state_ = other.null_state_;
    }
    for (std::size_t index = 0; index < size_; index++) {
      array_desc_.base_addr[index] = other.array_desc_.base_addr[index];
    }
    return *this;
  }

  std::size_t size() const { return size_; }

  std::size_t dim_size(std::size_t i) const { return dims_[i]; }

  CFI_cdesc_t* CFIDescriptorPointer() const {
    return ntcl::internal::GetBasicPointer(
        const_cast<ntcl::internal::CFI_tpl_cdesc_t<T, R>*>(&array_desc_));
  }

  CFI_cdesc_t* CFIDescriptorPointer() {
    return ntcl::internal::GetBasicPointer(&array_desc_);
  }

  void swap(FArrayData<T, R>& other) noexcept {
    using std::swap;

    swap(array_desc_, other.array_desc_);
    swap(dims_, other.dims_);
    swap(strides_, other.strides_);
    swap(size_, other.size_);
    swap(null_state_, other.null_state_);
  }

 protected:
  // Private default constructor for fast move operations
  FArrayData() : null_state_(true) {}
};

// Swap function
template <typename T, std::size_t R>
void swap(FArrayData<T, R>& a, FArrayData<T, R>& b) noexcept {
  a.swap(b);
}

}  // namespace internal

template <typename T, std::size_t R>
class FArray : public ntcl::internal::FArrayData<T, R> {
 public:
  template <typename... Args,
            typename = typename std::enable_if<sizeof...(Args) == R>::type>
  explicit FArray(Args&&... args)
      : ntcl::internal::FArrayData<T, R>(
            ntcl::internal::ParameterPackToSizeTArray(
                std::forward<Args>(args)...)) {}
  FArray(const FArray<T, R>& other) : ntcl::internal::FArrayData<T, R>(other) {}
  FArray(FArray<T, R>&& other) noexcept : ntcl::internal::FArrayData<T, R>() {
    swap(other);
  }
  ~FArray() {}
  void swap(FArray<T, R>& other) noexcept {
    using ntcl::internal::FArrayData;
    using std::swap;
    swap(static_cast<FArrayData<T, R>&>(*this),
         static_cast<FArrayData<T, R>&>(other));
  }

  template <typename... Args,
            typename = typename std::enable_if<sizeof...(Args) == R>::type>
  T operator()(Args&&... args) const {
    return (*this)(
        ntcl::internal::ParameterPackToSizeTArray(std::forward<Args>(args)...));
  }

  template <typename... Args,
            typename = typename std::enable_if<sizeof...(Args) == R>::type>
  T& operator()(Args&&... args) {
    return (*this)(
        ntcl::internal::ParameterPackToSizeTArray(std::forward<Args>(args)...));
  }

 private:
  T operator()(const std::array<std::size_t, R>& indices) const {
    return ntcl::internal::FArrayData<T, R>::array_desc_
        .base_addr[ntcl::internal::ComputeIndex(
            indices, ntcl::internal::FArrayData<T, R>::strides_)];
  }

  T& operator()(const std::array<std::size_t, R>& indices) {
    return ntcl::internal::FArrayData<T, R>::array_desc_
        .base_addr[ntcl::internal::ComputeIndex(
            indices, ntcl::internal::FArrayData<T, R>::strides_)];
  }
};

// Rank 1 specialization
template <typename T>
class FArray<T, 1> : public ntcl::internal::FArrayData<T, 1> {
 public:
  explicit FArray(std::size_t dim_i)
      : ntcl::internal::FArrayData<T, 1>({dim_i}) {}
  FArray(const FArray<T, 1>& other) : ntcl::internal::FArrayData<T, 1>(other) {}
  FArray(FArray<T, 1>&& other) noexcept : ntcl::internal::FArrayData<T, 1>() {
    swap(other);
  }
  ~FArray() {}
  void swap(FArray<T, 1>& other) noexcept {
    using ntcl::internal::FArrayData;
    using std::swap;
    swap(static_cast<FArrayData<T, 1>&>(*this),
         static_cast<FArrayData<T, 1>&>(other));
  }

  T operator()(std::size_t i) const {
    return ntcl::internal::FArrayData<T, 1>::array_desc_.base_addr[i];
  }

  T& operator()(std::size_t i) {
    return ntcl::internal::FArrayData<T, 1>::array_desc_.base_addr[i];
  }
};

// Rank 2 specialization
template <typename T>
class FArray<T, 2> : public ntcl::internal::FArrayData<T, 2> {
 public:
  explicit FArray(std::size_t dim_i, std::size_t dim_j)
      : ntcl::internal::FArrayData<T, 2>({dim_i, dim_j}) {}
  FArray(const FArray<T, 2>& other) : ntcl::internal::FArrayData<T, 2>(other) {}
  FArray(FArray<T, 2>&& other) noexcept : ntcl::internal::FArrayData<T, 2>() {
    swap(other);
  }
  ~FArray() {}
  void swap(FArray<T, 2>& other) noexcept {
    using ntcl::internal::FArrayData;
    using std::swap;
    swap(static_cast<FArrayData<T, 2>&>(*this),
         static_cast<FArrayData<T, 2>&>(other));
  }

  T operator()(std::size_t i, std::size_t j) const {
    using ntcl::internal::FArrayData;
    return FArrayData<T, 2>::array_desc_
        .base_addr[i + FArrayData<T, 2>::strides_[1] * j];
  }

  T& operator()(std::size_t i, std::size_t j) {
    using ntcl::internal::FArrayData;
    return FArrayData<T, 2>::array_desc_
        .base_addr[i + FArrayData<T, 2>::strides_[1] * j];
  }
};

// Rank 3 specialization
template <typename T>
class FArray<T, 3> : public ntcl::internal::FArrayData<T, 3> {
 public:
  explicit FArray(std::size_t dim_i, std::size_t dim_j, std::size_t dim_k)
      : ntcl::internal::FArrayData<T, 3>({dim_i, dim_j, dim_k}) {}
  FArray(const FArray<T, 3>& other) : ntcl::internal::FArrayData<T, 3>(other) {}
  FArray(FArray<T, 3>&& other) noexcept : ntcl::internal::FArrayData<T, 3>() {
    swap(other);
  }
  ~FArray() {}
  void swap(FArray<T, 3>& other) noexcept {
    using ntcl::internal::FArrayData;
    using std::swap;
    swap(static_cast<FArrayData<T, 3>&>(*this),
         static_cast<FArrayData<T, 3>&>(other));
  }

  T operator()(std::size_t i, std::size_t j, std::size_t k) const {
    using ntcl::internal::FArrayData;
    return FArrayData<T, 3>::array_desc_
        .base_addr[i + FArrayData<T, 3>::strides_[1] * j +
                   FArrayData<T, 3>::strides_[2] * k];
  }

  T& operator()(std::size_t i, std::size_t j, std::size_t k) {
    using ntcl::internal::FArrayData;
    return FArrayData<T, 3>::array_desc_
        .base_addr[i + FArrayData<T, 3>::strides_[1] * j +
                   FArrayData<T, 3>::strides_[2] * k];
  }
};

// Rank 4 specialization
template <typename T>
class FArray<T, 4> : public ntcl::internal::FArrayData<T, 4> {
 public:
  explicit FArray(std::size_t dim_i, std::size_t dim_j, std::size_t dim_k,
                  std::size_t dim_l)
      : ntcl::internal::FArrayData<T, 4>({dim_i, dim_j, dim_k, dim_l}) {}
  FArray(const FArray<T, 4>& other) : ntcl::internal::FArrayData<T, 4>(other) {}
  FArray(FArray<T, 4>&& other) noexcept : ntcl::internal::FArrayData<T, 4>() {
    swap(other);
  }
  ~FArray() {}
  void swap(FArray<T, 4>& other) noexcept {
    using ntcl::internal::FArrayData;
    using std::swap;
    swap(static_cast<FArrayData<T, 4>&>(*this),
         static_cast<FArrayData<T, 4>&>(other));
  }

  T operator()(std::size_t i, std::size_t j, std::size_t k,
               std::size_t l) const {
    using ntcl::internal::FArrayData;
    return FArrayData<T, 4>::array_desc_
        .base_addr[i + FArrayData<T, 4>::strides_[1] * j +
                   FArrayData<T, 4>::strides_[2] * k +
                   FArrayData<T, 4>::strides_[3] * l];
  }

  T& operator()(std::size_t i, std::size_t j, std::size_t k, std::size_t l) {
    using ntcl::internal::FArrayData;
    return FArrayData<T, 4>::array_desc_
        .base_addr[i + FArrayData<T, 4>::strides_[1] * j +
                   FArrayData<T, 4>::strides_[2] * k +
                   FArrayData<T, 4>::strides_[3] * l];
  }
};
}  // namespace ntcl
#endif  // NTCL_DATA_F_ARRAY_H_
