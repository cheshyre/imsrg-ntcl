// Copyright 2022 Matthias Heinz
// This module exists to manage the mappings from C/C++ types to CFI type and
// size specifiers.
// It DOES NOT support CFI_type_other and CFI_type_cfunptr types.
#ifndef NTCL_DATA_CFI_TYPES_H_
#define NTCL_DATA_CFI_TYPES_H_

#include <ISO_Fortran_binding.h>

#include <complex>
#include <cstdint>
#include <cstdlib>

#include <type_traits>

namespace ntcl {
namespace internal {

// General definitions
template <typename T>
struct CFI_Type {
  static constexpr CFI_type_t value = CFI_type_struct;
};

template <typename T>
struct CFI_Type<T*> {
  static constexpr CFI_type_t value = CFI_type_cptr;
};

template <>
struct CFI_Type<std::size_t> {
  static constexpr CFI_type_t value = CFI_type_size_t;
};

template <>
struct CFI_Type<std::int8_t> {
  static constexpr CFI_type_t value = CFI_type_int8_t;
};

template <>
struct CFI_Type<std::int16_t> {
  static constexpr CFI_type_t value = CFI_type_int16_t;
};

template <>
struct CFI_Type<std::int32_t> {
  static constexpr CFI_type_t value = CFI_type_int32_t;
};

template <>
struct CFI_Type<std::int64_t> {
  static constexpr CFI_type_t value = CFI_type_int64_t;
};

template <>
struct CFI_Type<float> {
  static constexpr CFI_type_t value = CFI_type_float;
};

template <>
struct CFI_Type<double> {
  static constexpr CFI_type_t value = CFI_type_double;
};

template <>
struct CFI_Type<long double> {
  static constexpr CFI_type_t value = CFI_type_long_double;
};

template <>
struct CFI_Type<float _Complex> {
  static constexpr CFI_type_t value = CFI_type_float_Complex;
};

template <>
struct CFI_Type<double _Complex> {
  static constexpr CFI_type_t value = CFI_type_double_Complex;
};

template <>
struct CFI_Type<long double _Complex> {
  static constexpr CFI_type_t value = CFI_type_long_double_Complex;
};

template <>
struct CFI_Type<std::complex<float>> {
  static constexpr CFI_type_t value = CFI_type_float_Complex;
};

template <>
struct CFI_Type<std::complex<double>> {
  static constexpr CFI_type_t value = CFI_type_double_Complex;
};

template <>
struct CFI_Type<std::complex<long double>> {
  static constexpr CFI_type_t value = CFI_type_long_double_Complex;
};

template <>
struct CFI_Type<bool> {
  static constexpr CFI_type_t value = CFI_type_Bool;
};

template <>
struct CFI_Type<char> {
  static constexpr CFI_type_t value = CFI_type_char;
};

template <typename T>
inline constexpr CFI_type_t CFI_Type_v = CFI_Type<T>::value;

template <typename T>
inline constexpr std::size_t CFI_Size_v = sizeof(T);

}  // namespace internal
}  // namespace ntcl

#endif  // NTCL_DATA_CFI_TYPES_H_
