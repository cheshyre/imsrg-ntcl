DEBUG=1

def debug_print(debug_statement):
    if DEBUG>0: print(debug_statement)
