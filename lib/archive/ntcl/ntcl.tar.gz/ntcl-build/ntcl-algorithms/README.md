NTCL algorithms
